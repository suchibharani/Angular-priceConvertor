/*global define*/
define([
	'jquery',
	'underscore',
	'backbone',
	'models/book',
	'collections/allbooks',
	'text!templates/readbooks.html'
], function ($, _, Backbone, Book,  AllBooks, AllReadBooksTemplate) {
	'use strict';
    
	var bookReadView = Backbone.View.extend({
        
    template: _.template(AllReadBooksTemplate),
    
    initialize: function() {
        AllBooks.fetch();
        AllBooks.bind("reset", this.render, this);
    },
    render: function(){

        console.log(AllBooks);
        var renderedContent = this.template({books : AllBooks.toJSON()});
        $(this.el).html(renderedContent);
        return this;
//        for (var n in this.collection.models) {
//            this.$el.html(this.template({ rbook : this.collection.models[n].toJSON() }));   
//        }
//         return this;
    },
    events: {
        
    }

	});

	return bookReadView;
});