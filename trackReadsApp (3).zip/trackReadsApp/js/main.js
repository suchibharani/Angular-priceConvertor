/*global require*/
'use strict';

// Require.js allows us to configure shortcut alias
require.config({
	// The shim config allows us to configure dependencies for
	// scripts that do not call define() to register a module
    paths: {
		jquery: 'libs/jquery',
		underscore: 'libs/underscore',
		backbone: 'libs/backbone',
		backboneLocalstorage: 'libs/backbone.localStorage',
		text: 'libs/text',
        hammerjs: 'libs/hammer',
        jhammerjs: 'libs/jquery.hammer',
        velocity: 'libs/velocity',
        scrollfire: 'libs/scrollfire',
        templates:'../templates',
        materialize: 'libs/materialize.min'
	},
	shim: {
		underscore: {
			exports: '_'
		},
        jquery: {
            exports: '$'
        },
        velocity: {
            deps: [ 'jquery' ]
        },
		backbone: {
			deps: [
                'jquery',
				'underscore'
			],
			exports: 'Backbone'
		},
		backboneLocalstorage: {
			deps: ['backbone'],
			exports: 'Store'
		},
        scrollfire:{
         deps: [
                'jquery'
			], 
            exports: 'scrollfire'
        },
        materialize: {
            deps: [
                'jquery',
                'hammerjs',
                'jhammerjs',
                'scrollfire',
                'velocity'
			],
            exports: 'materialize'
        }
	}
});

require(['app'], function (App) {
    App.initialize();
});