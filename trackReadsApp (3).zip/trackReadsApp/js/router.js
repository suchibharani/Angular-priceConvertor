define([
    'jquery',
    'underscore',
    'backbone',
    'views/home',
    'views/bookread'
], function ($, _, Backbone, IndexView, BookRead) {
    var AppRouter = Backbone.Router.extend({
        routes: {
            '': 'home',
            'home': 'home',
            'books':'allread',
        },

        home: function(){
            $('#book-list').empty();
            indexView = new IndexView({ el: $('#main') });
            indexView.render();
        },
        allread: function(){
            console.log("allread");
            $('#book-list, #main').empty();
            bookread = new BookRead({ el: $('#book-list') });
            bookread.render();
        }
    });

    var initialize = function(){
        var app_router = new AppRouter();
        Backbone.history.start();
    };
    return {
        initialize: initialize
    };
});