define(['jquery', 'underscore', 'backbone', 'router', 'materialize' ], function($, _, Backbone, Router, materialize) {
    var initialize = function(){
        Router.initialize();
        $(".button-collapse").sideNav();
    };

    return {
        initialize: initialize
    };
});