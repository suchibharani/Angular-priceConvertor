define([
    'jquery',
    'underscore',
    'backbone'
], function ($, _, Backbone) {
    var AppRouter = Backbone.Router.extend({
        routes: {
            '*path': 'home',
            'home': 'home',
            'readit':'readit',
        },

        home: function(){
            console.log("home");
        },
        readit: function(){

        }
    });

    var initialize = function(){
        var app_router = new AppRouter;
        Backbone.history.start();
    };
    return {
        initialize: initialize
    };
});