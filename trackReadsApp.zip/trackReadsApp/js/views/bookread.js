/*global define*/
define([
	'jquery',
	'underscore',
	'backbone'
], function ($, _, Backbone) {
	'use strict';

	// Our overall **AppView** is the top-level piece of UI.
	var bookReadView = Backbone.View.extend({
     //template: _.template($('#allreadlist').html()),
    
    initialize: function(options) {
       
    },
    render: function(){
//        this.$el.html(
//    	this.template({ rbook : this.model.attributes})
//        );
//        return this;
    },
    events: {
        
    },
    saveitnow: function(readBook){
//        var saveModel = new trackReadsApp.Models.Book();
//        saveModel.set({
//          title: readBook.volumeInfo.title,
//          author: readBook.volumeInfo.authors,
//          description: readBook.searchInfo.textSnippet,
//          thumbnail: readBook.volumeInfo.imageLinks.thumbnail,
//          read: true,
//          borrowed : false,
//          toWhom : "",
//        });
//         if (saveModel.isValid()) {
//          allCollection.fetch();
//          allCollection.add(saveModel);
//          saveModel.save();
//          Materialize.toast('Your selection added to Read list', 3000) 
//          //Backbone.history.navigate('readit', {trigger: true});
//    }
//    return allCollection;
    }

	});

	return bookReadView;
});