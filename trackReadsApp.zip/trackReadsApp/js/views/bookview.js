/*global define*/
define([
	'jquery',
	'underscore',
	'backbone',
    'text!../../templates/bookslist.html'
], function ($, _, Backbone, bookslistTemplate) {
	'use strict';

	// Our overall **AppView** is the top-level piece of UI.
	var singleBookView = Backbone.View.extend({
        
    initialize: function() {
    },
    render: function(){
    }

	});

	return singleBookView;
});
