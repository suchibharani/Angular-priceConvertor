/*global define*/
define([
	'underscore',
	'backbone'
], function (_, Backbone) {
	'use strict';

	var Book = Backbone.Model.extend({
		// you can set any defaults you would like here
      defaults: {
        title: "",
        description: "",
        author: "",
        thumbnail: "",
        read: true,
        borrowed : false,
        toWhom : "",
        // just setting random number for id would set as primary key from server
        id: _.random(0, 10000)
      },
    initialize: function(options)   {},
	});

	return Book;
});