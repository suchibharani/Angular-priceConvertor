define([
       'jquery',
       'underscore',
       'backbone',
       'router',
        'materialize'
       ],
       function($, _, Backbone, BaseRouter, materialize){
         var initialize = function(){
          BaseRouter.initialize();
            $(".button-collapse").sideNav(); 
         }

         return { initialize: initialize };
       });