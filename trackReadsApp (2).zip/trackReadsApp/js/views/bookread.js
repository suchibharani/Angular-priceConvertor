/*global define*/
define([
	'jquery',
	'underscore',
	'backbone',
	'models/book',
	'collections/allbooks',
	'text!templates/bookslist.html'
], function ($, _, Backbone, Book,  AllBooks, AllReadBooksTemplate) {
	'use strict';
    
	var bookReadView = Backbone.View.extend({
        
    template: _.template(AllReadBooksTemplate),
    
    initialize: function() {

    },
    render: function(){
        var bookrReadView;

        for (var n in AllBooks.models) {

            //bookrReadView = new BookView({model: books.models[n]});
            this.$el.html(this.template({ book : this.model.toJSON() }));
			return this;
        }
//        this.$el.html(
//        this.template({ rbook : this.model.toJSON() }));
//        return this;
    },
    events: {
        
    }

	});

	return bookReadView;
});