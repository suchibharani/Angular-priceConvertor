/*global define*/
define([
	'jquery',
	'underscore',
	'backbone',
    'collections/books',
    'views/bookview' 
], function ($, _, Backbone, Books, BookView) {
	'use strict';

	// Our overall **AppView** is the top-level piece of UI.
	var HomeAppView = Backbone.View.extend({
        
        initialize: function(options) {},
    template: "<div class='row card mtb_20 '><form><div class='input-field col s12 '><i class='material-icons prefix'>search</i><input id='icon_prefix' type='text' class='validate'><label for='icon_prefix' data-success='right' data-error='wrong'>Search for books</label></div><div class='col s12 mtb_20'><button class='btn waves-effect waves-light pull-right pink darken-1' id='searchnow' type='submit' name='action'>Submit<i class='material-icons right'>send</i></button> </div></form><div>",

    render: function()
    {
        this.$el.html(this.template);       
        return this;
    },
     events: {
        'click button#searchnow' : 'getbooks'
    },
    getbooks: function(event) {
        event.stopPropagation();
        event.preventDefault();
        $('#book-list').empty();
        var title = this.$el.find('input').val();
        if(title){
             var books = new Books({title: title});
             books.fetch({success: this.renderbooks.bind(this)});
        }
        else{
            this.$el.find('.validate').addClass('invalid');
        }
    },
    renderbooks: function(books){
        var bookview;

        for (var n in books.models) {

            bookview = new BookView({model: books.models[n]});

            $('#book-list').append(bookview.render().el);
        }
    }

	});

	return HomeAppView;
});