/*global define*/
define([
	'jquery',
	'underscore',
	'backbone',
    'models/book',
	'collections/allbooks',
	'text!templates/bookslist.html',
    'materialize'
], function ($, _, Backbone, Book, AllBooks, bookListTemplate, materialize) {
	'use strict';

	var bookView = Backbone.View.extend({


		template: _.template(bookListTemplate),

		// The DOM events specific to an item.
		events: {
            "click .saveit" :'saveit'
		},
		initialize: function(options) {
        if (options.model)
            this.model = options.model;
        },

		// Re-render the titles of the todo item.
		render: function () {
            
			this.$el.html(this.template({ book : this.model.toJSON() }));
			return this;
		},
        saveit: function(event){
        
        event.stopPropagation();
        event.preventDefault();
        var readBook = this.model.attributes;
        var book = new Book();
         book.set({
          title: readBook.volumeInfo.title,
          author: readBook.volumeInfo.authors,
          description: readBook.searchInfo.textSnippet,
          thumbnail: readBook.volumeInfo.imageLinks.thumbnail,
          read: true,
          borrowed : false,
          toWhom : "",
        });
        if (book.isValid()) {
          AllBooks.fetch();
          AllBooks.add(book);
          book.save();
          Materialize.toast('Your selection added to Read list', 3000) 
          Backbone.history.navigate('allread', {trigger: true});
        }
            
    }
	});

	return bookView;
});
