define([
    'jquery',
    'underscore',
    'backbone',
    'views/home',
    'views/bookread'
], function ($, _, Backbone, IndexView, BookRead) {
    var AppRouter = Backbone.Router.extend({
        routes: {
            '': 'home',
            'home': 'home',
            'allread':'allread',
        },

        home: function(){
            indexView = new IndexView({ el: $('#main') });
            indexView.render();
        },
        allread: function(){
            console.log("allread");
            bookread = new BookRead({ el: $('#book-list') });
            bookread.render();
        }
    });

    var initialize = function(){
        var app_router = new AppRouter();
        Backbone.history.start();
    };
    return {
        initialize: initialize
    };
});