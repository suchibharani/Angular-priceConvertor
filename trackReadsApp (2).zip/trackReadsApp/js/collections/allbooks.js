/*global define */
define([
	'underscore',
	'backbone',
	'backboneLocalstorage',
	'models/book'
], function (_, Backbone, Store, Book) {
	'use strict';

	var AllBooksCollection = Backbone.Collection.extend({

		// Reference to this collection's model.
        localStorage: new Store("Readbooks"),
        
        model: Book,
        
        initialize: function(){ 
            
        }
	});

	return new AllBooksCollection();
});