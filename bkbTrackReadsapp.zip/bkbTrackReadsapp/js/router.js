trackReadsApp.Router = Backbone.Router.extend({

    routes: {
        'home': 'home',
        '*path': 'home'
    },

    home: function(){
        var view = new trackReadsApp.Views.Home();
        $('#main').html(view.render().el);
    }
});