var trackReadsApp = {

    Views: {},
    Models: {},
    Collections: {},
    Router: {}
}

$(document).ready(function(){
    trackReadsApp.Router.Instance = new trackReadsApp.Router();   
    Backbone.history.start();
});