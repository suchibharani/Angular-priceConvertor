trackReadsApp.Models.Books = Backbone.Model.extend({

    initialize: function(options)   {},
});