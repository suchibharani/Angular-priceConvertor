trackReadsApp.Views.Home = Backbone.View.extend({

    initialize: function(options) {},
    template: "<div class='input-field col s12 '><i class='material-icons prefix'>search</i><input id='icon_prefix  pink darken-1' type='text' class='validate'><label for='icon_prefix'>Search for books</label></div><div class='col s12 mtb_20'><button class='btn waves-effect waves-light pull-right pink darken-1' id='searchnow' type='submit' name='action'>Submit<i class='material-icons right'>send</i></button> </div>",

    render: function()
    {
        this.$el.html(this.template);       
        return this;
    },
     events: {
        'click button#searchnow' : 'getmovies'
    },
    getmovies: function() {

        var title = this.$el.find('input').val();
        console.log(title);
        var books = new trackReadsApp.Collections.Books({title: title});
        console.log(books.fetch());
    }
});