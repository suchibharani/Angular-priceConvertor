trackReadsApp.Collections.allBooks = Backbone.Collection.extend({
    // Reference to this collection's model.
    localStorage: new Backbone.LocalStorage("trackReadsApp.Collections.allBooks"),
    model: trackReadsApp.Models.Book,
    initialize: function(){  
    }
 });  