trackReadsApp.Router = Backbone.Router.extend({

    routes: {
        'home': 'home',
        'readit':'readit',
        '*path': 'home'
    },

    home: function(){
        $('#book-list').empty();
        var view = new trackReadsApp.Views.Home();
        $('#main').html(view.render().el);
        
    },
    readit: function(){
      
    }
});