trackReadsApp.Views.BookView = Backbone.View.extend({
    
    template: _.template($('#indexTemplate').html()),
    
    initialize: function(options) {
        if (options.model)
            this.model = options.model;
    },
    render: function(){
        this.$el.html(
    	this.template({ book : this.model.attributes})
        );
        return this;
    },
    events: {
        "click .saveit" : "saveit"
    },
    saveit: function(event){
        event.stopPropagation();
        event.preventDefault();
        var view = new trackReadsApp.Views.BookReadIt();
        var readBook = this.model.attributes;
       // update our model with values from the form
        var allcollections = view.saveitnow(readBook);
        this.renderReadView.bind(allcollections)
    },
    renderReadView: function(allcollections){
        var allcollections;

        for (var n in allcollections.models) {

            allcollectionsview = new trackReadsApp.Views.BookReadIt({model: allcollections.models[n]});

            $('#book-list').append(allcollectionsview.render().el);
        }
    }
})